import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:medicompare/Home/bloc/home_bloc.dart';
import 'package:medicompare/Home/screens/home_screen.dart';
import 'package:medicompare/appointmrnt%20details/screen/appointment_details_screen.dart';
import 'package:medicompare/bottomNavigate/bloc/bottom_nav_bloc.dart';
import 'package:medicompare/bottomNavigate/screen/dashboard_navigation.dart';
import 'package:medicompare/core/routes/router_name.dart';
import 'package:medicompare/create_pin/bloc/pin_bloc.dart';
import 'package:medicompare/create_pin/screens/create_pin_screen.dart';
import 'package:medicompare/document%20verification/doctor_verification_screen.dart';
import 'package:medicompare/document%20verification/document_verification_bloc.dart';
import 'package:medicompare/login_files/login_bloc.dart';
import 'package:medicompare/login_files/login_screen.dart';
import 'package:medicompare/menubar/bloc/profile_bloc.dart';
import 'package:medicompare/menubar/screens/profile_screen.dart';
import 'package:medicompare/otp_verify/bloc/otp_bloc.dart';
import 'package:medicompare/otp_verify/screens/verify_otp_screen.dart';
import 'package:medicompare/patients/bloc/patients_bloc.dart';
import 'package:medicompare/patients/bloc/patients_repository.dart';
import 'package:medicompare/patients/screens/patients_screen.dart';
import 'package:medicompare/register_files/doctor_registration_bloc.dart';
import 'package:medicompare/register_files/register_screen.dart';
import 'package:medicompare/schedule/bloc/schedule_bloc.dart';
import 'package:medicompare/schedule/screens/schedule_screen.dart';
import 'package:medicompare/today_aptmnt/bloc/appointment_bloc.dart';
import 'package:medicompare/today_aptmnt/screen/appointments_screen.dart';

class AppRoutes {
  static Route<dynamic> generate(RouteSettings settings) {
    switch (settings.name) {
      case RouteNames.login:
        return MaterialPageRoute(
          // builder: (_) => const LoginScreen()
          builder: (_) => BlocProvider(
            create: (_) => LoginBloc(),
            child: const LoginScreen(),
          ),
        );

      case RouteNames.register:
        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => DoctorRegistrationBloc(),
            child: const RegisterScreen(),
          ),
        );

      case RouteNames.otp:
        String phoneNumber = settings.arguments.toString();
        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => OtpBloc(),
            child: VerifyOtpScreen(phoneNumber: phoneNumber),
          ),
        );

      case RouteNames.document_verify:
        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => DocumentVerificationBloc(),
            child: const DoctorVerificationScreen(),
          ),
        );
      case RouteNames.createpin:
        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => PinBloc(),
            child: const CreatePinScreen(),
          ),
        );
      case RouteNames.home:
        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => HomeBloc(),
            child: const HomeScreen(),
          ),

          ///  builder: (_) => const DoctorVerificationScreen(),
        );
      case RouteNames.menubar:
        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => ProfileBloc(),
            child: const ProfileScreen(),
          ),
        );
      case RouteNames.todayApartment:
        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => AppointmentBloc(),
            child: const AppointmentsScreen(),
          ),
        );
      case RouteNames.schedule:
        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => ScheduleBloc(),
            child: const ScheduleScreen(),
          ),
        );
      case RouteNames.homeBottomNav:
        return MaterialPageRoute(
          builder: (_) =>
              BlocProvider(create: (_) => BottomNavBloc(), child: MainScreen()),
        );
      // case RouteNames.patients:
      //   final repository = settings.arguments as PatientsRepository;

      //   return MaterialPageRoute(
      //     builder: (_) => BlocProvider(
      //       create: (_) => PatientsBloc(repository: repository),
      //       child: const PatientsScreen(),
      //     ),
      //   );
      case RouteNames.todayApartmentdtls:
        String appointmentId = settings.arguments.toString();
        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => AppointmentBloc(),
            child: AppointmentDetailsScreen(appointmentId: appointmentId),
          ),
        );

      case RouteNames.patients:
        final repository = settings.arguments as PatientsRepository;

        return MaterialPageRoute(
          builder: (_) => BlocProvider(
            create: (_) => PatientsBloc(repository: repository),
            child: const PatientsScreen(),
          ),
        );

      default:
        return MaterialPageRoute(
          builder: (_) =>
              const Scaffold(body: Center(child: Text("Route Not Found"))),
        );
    }
  }
}
