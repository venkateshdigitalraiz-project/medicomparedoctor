class RouteNames {
  static const splash = "/";
  static const login = "/login";
  static const otp = "/otp";
  static const register = "/register";
  static const home = "/home";
  static const createpin = "/createpin";
  static const menubar = "/menubar";
  static const todayApartment = "/todayApartment";
  static const todayApartmentdtls = "/todayApartmentdtls";
  static const apartment = "/apartment";
  static const schedule = "/schedule";
  static const homeBottomNav = "/homeBottomNav";
  static const patients = "/patients";
  static const document_verify = "/documenr_verify";
  //AppointmentsCubit
}
