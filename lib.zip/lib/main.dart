// import 'package:flutter/material.dart';
// import 'package:flutter_bloc/flutter_bloc.dart';
// import 'package:medicompare/register_files/register_doctor_screen.dart';

// void main() {
//   runApp(BlocProvider(create: (_) => AuthBloc(), child: const MyApp()));
// }

// class MyApp extends StatelessWidget {
//   const MyApp({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return const MaterialApp(
//       debugShowCheckedModeBanner: false,
//       home: LoginScreen(), //LoginScreen(),
//     );
//   }
// }
// // import 'package:flutter/material.dart';
// // import 'package:medicompare/features/auth/presentation/pages/loginpage.dart';
// // import 'package:medicompare/register_files/register_doctor_screen.dart';

// // void main() {
// //   runApp(const MyApp());
// // }

// // class MyApp extends StatelessWidget {
// //   const MyApp({super.key});

// //   @override
// //   Widget build(BuildContext context) {
// //     return MaterialApp(
// //       title: 'Medi Compares',
// //       debugShowCheckedModeBanner: false,
// //       theme: ThemeData(
// //         primaryColor: const Color(0xFF5B2A8C),
// //         fontFamily: 'Roboto',
// //       ),
// //       routes: {
// //         '/': (context) => const LoginScreen(),
// //         '/register': (context) => const RegisterDoctorScreen(),
// //       },
// //       initialRoute: '/',
// //     );
// //   }
// // }

import 'package:flutter/material.dart';
import 'package:medicompare/core/routes/app_routes.dart';
import 'package:medicompare/core/routes/router_name.dart';
import 'package:medicompare/document%20verification/doctor_verification_screen.dart';
import 'package:medicompare/login_files/login_screen.dart';
import 'package:medicompare/otp_verify/screens/verify_otp_screen.dart';
import 'package:medicompare/register_files/register_screen.dart';
// import 'package:medicompare/register_files/register_doctor_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Medi Compares',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primaryColor: const Color(0xFF5B2A8C),
        fontFamily: 'Roboto',
      ),

      initialRoute: RouteNames.login,
      onGenerateRoute: AppRoutes.generate,
    );
  }
}
